// material-ui
import { Typography } from '@mui/material';

// project import
import ComponentSkeleton from './ComponentSkeleton';
import MainCard from 'components/MainCard';


// ============================|| ANT ICONS ||============================ //

const AntIcons = () => (
  <ComponentSkeleton>
    <MainCard title="Utilities 4">
      <Typography variant="subtitle2" color="textSecondary">
        Utilities 4
      </Typography>
    </MainCard>
  </ComponentSkeleton>
);

export default AntIcons;
